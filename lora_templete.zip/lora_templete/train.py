import os
import json
import argparse

import torch
import deepspeed
from tqdm import tqdm
from torch.utils.data import DataLoader
from torch.utils.data.distributed import DistributedSampler
import torch.distributed as dist

from dataset import GPT2Dataset
from peft import LoraConfig, TaskType, get_peft_model

from transformers import GPT2LMHeadModel, T5Tokenizer

os.environ["MASTER_PORT"] = "" # your Master Port

DS_CONFIG = {
    "bf16": {
        "enabled": True,
    },
    "optimizer": {
        "type": "AdamW",
        "params": {
            "lr": 3e-5,
            "betas": [0.98, 0.999],
            "eps": 1e-9
        }
    },
    "scheduler": {
        "type": "WarmupLR",
        "params": {
            "warmup_min_lr": 1e-4,
            "warmup_max_lr": 3e-4,
            "warmup_num_steps": 300
        }
    },
    "zero_optimization": {
        "stage": 2,
        "allgather_partitions": True,
        "allgather_bucket_size": 2e8,
        "overlap_comm": True,
        "reduce_scatter": True,
        "reduce_bucket_size": 2e8,
        "contiguous_gradients": True,
        "offload_optimizer": {
              "device": "cpu"
         },
        "stage3_gather_16bit_weights_on_model_save": True
    },
    "steps_per_print":20000,
    "gradient_accumulation_steps": 1,
    "train_micro_batch_size_per_gpu": 2,
    "wall_clock_breakdown": False
}

LORA_R = 8
LORA_ALPHA = 16
LORA_DROPOUT = 0.1
TARGET_MODULES = None

lora_config = LoraConfig(
    r=LORA_R,
    lora_alpha=LORA_ALPHA,
    target_modules=TARGET_MODULES,
    lora_dropout=LORA_DROPOUT,
    task_type=TaskType.CAUSAL_LM
)

DATA_PATH = "To-your-data-path" # your data path

def get_train_data():
    datas = []
    prompt = 'Below is an instruction that describes a task, paired with an input that provides further context. Write a response that appropriately completes the request.'

    with open(DATA_PATH, 'r') as f:
        res_list = json.load(f)
        print(len(res_list))
        for res in tqdm(res_list):
            if res['input'] == "":
                text = prompt + '\n### Instruction:\n{}\n\n### Response:{}'.format(res['instruction'], res['output'])
            else:
                text = prompt + '\n### Instruction:\n{}\n\n### Input:\n{}\n\n### Response:{}'.format(res['instruction'], res['input'], res['output'])
            datas.append(text)
    return datas

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--local_rank",type=int,default=-1,help="local_rank for distributed training on gpus")
    parser.add_argument("--max_epoches",type=int,default=5,help="max epoches to run dataloader")
    parser.add_argument("--max_steps",type=int,default=20000,help="max steps model to step")
    parser.add_argument("--save_dir",type=str,default="./ckps",help="the floader to save ckpts(.pt)")
    parser = deepspeed.add_config_arguments(parser)
    args = parser.parse_args()

    device = torch.device("cuda")

    model_name = "To-your-BBT-model" # your model path

    tokenizer = T5Tokenizer.from_pretrained(model_name)
    model = GPT2LMHeadModel.from_pretrained(model_name)

    model = get_peft_model(model, lora_config)

    print("=======================================================")
    model.print_trainable_parameters()
    print("=======================================================")

    print("Model loading...")

    engine, _, _, _ = deepspeed.initialize(
        config=DS_CONFIG,
        model=model, 
        model_parameters=model.parameters(),
        #dist_init_required=True
    )

    torch.distributed.barrier()

    print("Model loaded. start tokenizing!")

    train_dataset = GPT2Dataset(tokenizer, get_train_data(), 256)

    print("tokenizing done!")

    train_sampler = DistributedSampler(
        train_dataset,
        num_replicas=engine.world_size,
        rank=engine.local_rank,
        shuffle=True
    )

    train_dataloader = DataLoader(
        dataset=train_dataset, 
        sampler=train_sampler,
        batch_size=DS_CONFIG["train_micro_batch_size_per_gpu"]
    )

    print("start training!")

    global_step = 0
    engine.train()
    for epoch in range(args.max_epoches):
        losses = []
        if torch.distributed.get_rank() != -1:
            train_sampler.set_epoch(epoch)
        if torch.distributed.get_rank() == 0:
            pbar = tqdm(range(len(train_dataloader)), desc=f"Epoch {epoch + 1}/{args.max_epoches}")

        microsteps_in_epoch = 0
        for batch in train_dataloader:
            loss = engine(
                input_ids=batch[0].to(device),
                attention_mask=batch[1].to(device),
                labels=batch[0].to(device)
            ).loss
            engine.backward(loss)
            engine.step()
            engine.zero_grad()

            global_step += 1
            microsteps_in_epoch += 1
            losses.append(loss.item())
            if torch.distributed.get_rank() == 0:
                pbar.update()
                pbar.set_description(f"Epoch {epoch + 1}/{args.max_epoches} | "
                                    f"Microstep: {microsteps_in_epoch} | "
                                    f"Loss: {sum(losses) / len(losses):.4f}")

        dist.barrier()
        if torch.distributed.get_rank() == 0:
            engine.save_pretrained(f'./ckps/epoch-{epoch+1}')
        dist.barrier()

        if torch.distributed.get_rank() == 0:
            pbar.close()
        if global_step >= args.max_steps:
            break



