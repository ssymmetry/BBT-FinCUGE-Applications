import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader, IterableDataset
import pdb

class GPT2Dataset(Dataset):
    '''
        GPT2训练方法的数据集构造，没有Padding，通过EOS来截断。
    '''
    def __init__(self, tokenizer, datas, max_length):
        super().__init__()
        self.datas = datas
        self.tokenizer = tokenizer
        self.max_length = max_length
        self.index = 0
        self._preprocess(max_length)
        

    def _preprocess(self,max_length):
        # print([data + self.tokenizer.eos_token for data in self.datas])
        # pdb.set_trace()
        self.data_encoding = self.tokenizer(''.join([data + self.tokenizer.eos_token for data in self.datas]),return_tensors="pt")

    def __len__(self):
        return len(self.data_encoding['input_ids'][0]) // self.max_length

    def __getitem__(self, index):
        return self.data_encoding["input_ids"][0][index * self.max_length : (index + 1) * self.max_length], \
                self.data_encoding["attention_mask"][0][index * self.max_length : (index + 1) * self.max_length]

class BertDataset(Dataset):
    '''
        每个case之间存在空行，每个case的长度不超过max_length。
    '''
    def __init__(self, tokenizer, datas, max_length):
        super().__init__()
        self.datas = datas
        self.tokenizer = tokenizer
        self.max_length = max_length
    
    def __len__(self):
        return len(self.datas)

    def __getitem__(self, index):
        data_encoding = self.tokenizer(
            self.datas[index] + self.tokenizer.eos_token,
            max_length=self.max_length,
            padding="max_length",
            truncation=True,
            return_tensors="pt"
        )
        return data_encoding["input_ids"][0], data_encoding["attention_mask"][0]

class GPTIterDataset(Dataset):
    def __init__(self, tokenizer, datas, max_length):
        self.datas = datas
        self.tokenizer = tokenizer
        self.max_length = max_length
        self.index = 0
        self.buffer_ids = []
        self.buffer_masks = []

    """ def sample_dataset(self):
        while True:
            buffer_ids = []
            buffer_masks = []
            sent = self.datas[self.index] + self.tokenizer.eos_token
            index = (index + 1) % len(self.datas)
            ids = self.tokenizer(sent)
            ids, masks = ids['input_ids'], ids['attention_mask']
            while len(ids) > 0:
                remaining = self.max_length - len(buffer_ids)
                if remaining > 0:
                    buffer_ids.extend(ids[:remaining])
                    buffer_masks.extend(masks[:remaining])
                    ids = ids[remaining:]
                    masks = masks[remaining:]
                if len(buffer_ids) >= self.max_length:
                    yield torch.tensor(buffer_ids), torch.tensor(buffer_masks)
            
    def __iter__(self):
        return self.sample_dataset() """

    def __len__(self):
        return len(self.datas)

    def __getitem__(self, index):
        while len(self.buffer_ids) < self.max_length:
            sent = self.tokenizer(self.datas[self.index] + self.tokenizer.eos_token)
            self.index = (self.index + 1) % len(self.datas)
            self.buffer_ids.extend(sent['input_ids'])
            self.buffer_masks.extend(sent['attention_mask'])

        ids = self.buffer_ids[:self.max_length]
        masks = self.buffer_masks[:self.max_length]
        self.buffer_ids = self.buffer_ids[self.max_length:]
        self.buffer_masks = self.buffer_masks[self.max_length:]
        return torch.tensor(ids), torch.tensor(masks)
        

        self.index = (self.index + 1) % len(self.datas)
        ids = self.tokenizer(sent)
        ids, masks = ids['input_ids'], ids['attention_mask']
        while len(ids) > 0:
            remaining = self.max_length - len(buffer_ids)
            if remaining > 0:
                buffer_ids.extend(ids[:remaining])
                buffer_masks.extend(masks[:remaining])
                ids = ids[remaining:]
                masks = masks[remaining:]
            if len(buffer_ids) >= self.max_length:
                return torch.tensor(buffer_ids), torch.tensor(masks)